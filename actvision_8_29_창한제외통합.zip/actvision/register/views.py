from django.shortcuts import render, redirect
import os, json
from google.cloud import storage
from google.cloud.storage import blob, bucket
from settings.update_json import *
# Create your views here.

def register(request):
    get_root_json_from_GCP()
    read_root_json()
    return render(request,'register.html')

def users_list(request): # 조회 버튼을 누르면 사용자 정보들을 불러옴 (사용자 = GCP 버켓 이름)
    return redirect('register.html')

def get_root_json_from_GCP(bucket_name="ynu-mcl-act"): # download the json
    # always raspi serial is 16 string
    os.system("rm -rf " + top_directory + "root/*") # initailizing the root file,
    blobs = storage_client.list_blobs(bucket_name)
    for i in blobs:
        if(i.name[17:21] == "root"):
            DOWNLOAD(bucket_name, i.name, top_directory + root_directory + i.name[0:16] + "_root.json") # download with serial + root.json

def read_root_json():
    json_list = os.listdir(top_directory + root_directory)
    json_info = []
    for i in range(len(json_list)):
        json_list[i] = root_directory + json_list[i]
        with open(json_list[i], 'r', encoding="utf-8-sig") as outfile:
            read_json_info = json.load(outfile)
            json_info.append(read_json_info)
    with open(top_directory + root_directory + "all_player.json", 'w', encoding="utf-8-sig") as inputfile:
        json.dump(json_info, inputfile, indent = 4, ensure_ascii=False) # not broken korean, ensure..
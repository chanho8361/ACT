from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from settings.update_json import *
from imgn.media_json import *
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
# Create your views here.

check_index = -1

def movie(request):
    play_list = directory_list()
    list_name = []
    list_date = []

    print(play_list)
    for i in range(len(play_list)):
        list_date.append(play_list[i][0:4] + '-' + play_list[i][4:6] + '-' + play_list[i][6:8] + ' (' + play_list[i][8:10] +':' +
                         play_list[i][10:12] +')') # 앞에 14자리 - 등록일
        list_name.append(play_list[i][14:])

    print("현재 등록된 재생목록->")
    print(list_name)  # 저장된 이미지 리스트

    global check_index
    list_index = int(check_index)
    media_list = []
    if (list_index != -1): # 체크된 상태라면 -> 해당 재생목록의 동영상들을 가져오기
        if list_index >= len(play_list):
            pass
        else:
            param_play_list_name = play_list[list_index]
            media_list = video_list_in_bucket(param_play_list_name)

    list_dict = {
        'list_name': list_name,  # 재생목록 -> 이름
        'list_date': list_date,  # 재생목록 -> 등록일
        'list_index': list_index,  # 체크 -> 인덱스
        'list_media': media_list,  # 선택된 재생목록 내 동영상
    }

    print("재생목록 내 동영상 리스트->")
    print(media_list)


    context = json.dumps(list_dict)
    return render(request, 'mov.html', {'context': context})


@csrf_exempt
def video_list(request):
    temp = request.POST['index']
    print(temp)


    global check_index
    check_index = temp

    return render(request, 'mov.html')
    #return redirect('movie.html')




@csrf_exempt
def upload_list(request):  # 재생목록 추가 ( GCP에 해당하는 이름의 디렉토리를 만듬)
    if request.method == 'POST':
        if request.is_ajax():
            print(request.POST['list'])    # 리스트 이름
            input = request.POST['list']
            list_name = input # 임시방편
            # -- 업로드 , 이런식으로 하면 오류 없이 디렉토리 생성가능
            now_kst = time_now()  # 현재시간 받아옴
            UPLOAD("ynu-mcl-act", 'test' , user_id + "/PLAY_LIST/" + now_kst.strftime("%Y%m%d%H%M%S") + str(list_name) + "/")
            return redirect('movie.html')
        else:
            print("ajax 통신 실패!")
            return redirect('movie.html')
    else:
        print("POST 호출 실패!")
        return redirect('movie.html')



def directory_list():   # 디렉토리가 '/'로 끝나는 특징을 사용해 디렉토리 이름만 추출
    play_list_name = play_list_in_bucket("ynu-mcl-act")  # 중복 확인을 위해 PLAY_LIST 하위 이름들의 배열
    list_name = []
    for i in range(len(play_list_name)):
        if play_list_name[i][-1:] == '/':
            list_name.append(play_list_name[i][:-1])
    return list_name


@csrf_exempt
def upload_video(request):  # 재생목록에 동영상 업로드
    if request.method == 'POST':
        if request.is_ajax():

            video_name = request.POST['video_name']  # 동영상 이름
            play_list_index = int(request.POST['list_name']) # 재생목록 인덱스
            if (play_list_index == -1):  # 재생목록이 선택되지 않은 상태라면 저장하지 않음
                return redirect('movie.html')
            video = request.FILES.get('video')  # 동영상을 request에서 받아옴
            path = default_storage.save(user_id + "/video", ContentFile(video.read()))
            play_list = directory_list()
            checked_play_list = play_list[play_list_index]
            now_kst = time_now()  # 현재시간 받아옴
# 찬호야 부탁해

            UPLOAD("ynu-mcl-act", user_id + "/video",user_id + "/PLAY_LIST/" + checked_play_list + now_kst.strftime("/%Y%m%d%H%M%S") + video_name)
            UPLOAD("ynu-mcl-act", "test" ,user_id + "/VIDEO_SCHEDULE/" + checked_play_list + now_kst.strftime("/%Y%m%d%H%M%S"))

            os.remove(user_id + "/video")  # 장고에서 중복된 이름의 파일에는 임의로 이름을 변경하기 때문에 임시파일은 제거
            return redirect('movie.html')
        else:
            print("ajax 통신 실패!")
            return redirect('movie.html')
    else:
        print("POST 호출 실패!")
        return redirect('movie.html')


@csrf_exempt
def delete_play_list(request):  # 선택된 재생목록 삭제
    if request.method == 'POST':
        if request.is_ajax():

            delete_index = int(request.POST['play_list_index'])
            play_list = directory_list()
            if (delete_index >= len(play_list)):
                pass
            else:
                delete_name = play_list[delete_index]
                delete_blob("ynu-mcl-act", user_id + "/PLAY_LIST/" + delete_name + "/")

            return redirect('movie.html')
        else:
            print("ajax 통신 실패!")
            return redirect('movie.html')
    else:
        print("POST 호출 실패!")
        return redirect('movie.html')


@csrf_exempt
def delete_video(request):  # 선택된 재생목록 삭제
    if request.method == 'POST':
        if request.is_ajax():

            # 구현 마저하시오


            return redirect('movie.html')
        else:
            print("ajax 통신 실패!")
            return redirect('movie.html')
    else:
        print("POST 호출 실패!")
        return redirect('movie.html')



@csrf_exempt
def play_schedule(request):
    if request.method == 'POST':
        if request.is_ajax():

            start_day = request.POST["start_day"]
            start_day = re.sub(r'[^0-9]', '', start_day)
            finish_day = request.POST["finish_day"]
            finish_day = re.sub(r'[^0-9]', '', finish_day)
            start_hour = request.POST["start_hour"]
            finish_hour = request.POST["finish_hour"]
            start_min = request.POST["start_min"]
            finish_min = request.POST["finish_min"]
            video_index = int(request.POST["video_index"])
            play_list_index = request.POST["play_list_index"]
            print(start_day , finish_day)
            # 선택한 인덱스의 파일이름을 가져와 14자리 떼어냄
            play_list = directory_list()
            play_list_name = play_list[int(play_list_index)] # 재생목록 이름 (14자리 포함)
            video_list = video_list_in_bucket_include_code(play_list_name) # 현재 보고있는 동영상 리스트
            file_code = video_list[video_index]  # file_code => 고유번호 14자리


            # VIDEO_SCHEDULE -> 선택 파일의 현재 이름
            rename_prev = schedule_list_in_bucket(play_list_name ,video_index)

            new_name = str(file_code) + start_day + finish_day + start_hour + start_min + finish_hour + finish_min
            # VIDEO_SCHEDULE에 등록한 스케쥴로 변경
            rename_blob("ynu-mcl-act" , user_id + "/VIDEO_SCHEDULE/" + play_list_name + "/" + rename_prev
                        ,user_id + "/VIDEO_SCHEDULE/" + play_list_name + "/" + new_name)



            return redirect('movie.html')
        else:
            print("ajax 통신 실패!")
            return redirect('movie.html')
    else:
        print("POST 호출 실패!")
        return redirect('movie.html')


@csrf_exempt
def play_list_trans(request):
    if request.method == 'POST':
        if request.is_ajax():
            play_list_index = int(request.POST["index"])

            # 인덱스로 재생목록 이름 따옴

            # 따온 재생목록 이름으로 동영상 스케쥴 폴더 -> 재생목록 이름 으로 접근

            # 해당 디렉토리의 이름들로 스케쥴 작성 , 일정 미작성 동영상(또는 과거) 모두 고려

            # 타임테이블을 새로작성하여 기존 타임테이블을 다 죽임

            return redirect('movie.html')
        else:
            print("ajax 통신 실패!")
            return redirect('movie.html')
    else:
        print("POST 호출 실패!")
        return redirect('movie.html')





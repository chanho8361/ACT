from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from settings.update_json import *
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from imgn.make_timetable import *
from PIL import ImageColor
from imgn.media_json import *
from urllib import parse
import numpy as np
import time
import os
#from django.utils import simplejson
# Create your views here.

def imgn(request):  # 페이지 로딩시 리스트에 이미지, 문자 올림
    img_list = img_list_in_bucket(user_id)  # 버켓안에 최신파일 이름 받아옴
    print("현재 저장된 이미지 목록->")
    print(img_list) # 저장된 이미지 리스트
    img_time_list = []
    img_name_list = []
    for i in range(len(img_list)): # img_list에서 시간이랑 이미지 이름 분리
        len_t = int(img_list[i][14]) # (지속시간 길이)
        img_time_list.append(str(img_list[i][15: 14 + len_t+1])) # 파일 이름 앞에 지속시간 분리 (첫자리 제외)
        img_name_list.append(str(img_list[i][14 + len_t+1:])) # 나머지 파일이름 따로 저장

    text_list = text_list_in_bucket(user_id)

    print("현재 저장된 문자 목록->")
    print(text_list) # 저장된 문자 리스트
    text_list_trans = []
    for i in range(len(text_list)):
        text_list_trans.append(text_list[i][14:])


    list_dict = {
        'img_name' : img_name_list,
        'img_time' : img_time_list,
        'text' : text_list_trans,
    }
    context = json.dumps(list_dict)
    return render(request, 'image.html', {'context': context})

@csrf_exempt
def upload_img(request):
    print("호출 성공")
    if request.method == 'POST':
        if request.is_ajax():

            stay_time = request.POST['time']    # 지속시간
            img_name = request.POST['img_name']  # 이미지 이름
            print(stay_time)
            img = request.FILES.get('img')  # 이미지를 request에서 받아옴
            path = default_storage.save(user_id +"/img.jpg", ContentFile(img.read()))
            now_kst = time_now()
            UPLOAD("ynu-mcl-act", user_id + "/img.jpg", user_id + "/IMAGE/" + now_kst.strftime("%Y%m%d%H%M%S") + str(len(stay_time)) + str(stay_time) + img_name)
            os.remove(user_id+"/img.jpg") # 장고에서 중복된 이름의 파일에는 임의로 이름을 변경하기 때문에 임시파일은 제거
            return redirect('image.html')
        else:
            print("ajax 통신 실패!")
            return redirect('image.html')
    else:
        print("POST 호출 실패!")
        return redirect('image.html')

@csrf_exempt
def save_letter(request): # 문자 설정 -> 확인 버튼 눌렀을 시 // 버켓 안 TEXT_LIST 디렉토리에 업로드하여 저장 (TIMETABLE을)
    if request != "":
        print("========= 시작 ===========")

        change = request_body_list_text(request.body)
        change[9] = parse.unquote(change[9])

        data = make_Timetable_text()
        now_kst = time_now_local()  # 현재시간 받아옴
        now_kst1 = time_now()
        now_kst += 15

        data[4]["detail_info"]["x"] = str(change[1])
        data[4]["detail_info"]["y"] = str(change[2])
        data[4]["detail_info"]["width"] = str(change[3])
        data[4]["detail_info"]["height"] = str(change[4])
        data[4]["detail_info"]["play_speed"] = str(change[5])
        data[4]["detail_info"]["play_count"] = str(change[6])
        data[4]["detail_info"]["font_size"] = "64"     # 폰트사이즈 - 인터페이스 수정 전까지 고정시킴
        data[4]["detail_info"]["scroll_fix"] = str(change[10])
        data[4]["detail_info"]["play_second"] = str(change[11])
        data[4]["title"] = str(change[0])
        hex = str("#" + change[8])
        rgb_value = ImageColor.getcolor(hex,"RGB")
        data[4]["detail_info"]["red_green_blue"] = str(rgb_value)

        data[4]["time"]["year"] = str(time.localtime(now_kst).tm_year)
        data[4]["time"]["month"] = str(time.localtime(now_kst).tm_mon)
        data[4]["time"]["day"] = str(time.localtime(now_kst).tm_mday)
        data[4]["time"]["hour"] = str(time.localtime(now_kst).tm_hour)
        data[4]["time"]["minute"] = str(time.localtime(now_kst).tm_min)
        data[4]["time"]["second"] = str(time.localtime(now_kst).tm_sec)

        if (str(change[10]) == '0'):
            title = str(change[0])
            len_text = len(title)
            all_text_pixel = int(0.9 * int(len_text) * int(data[4]["detail_info"]["font_size"])) - int(change[3])
            micro_second = (all_text_pixel * 100) / int(change[5]) # 100 is ms
            ans = np.rint((micro_second / 1000) * int(change[6]))
            now_kst = now_kst + 15 + ans
        elif (str(change[10]) == '1'):
            now_kst += 15 + int(change[11])
        else:
            print("스크롤-고정 선택 오류")
            return redirect('image.html')

        createDirectory(user_id)
        save_file(data)
        UPLOAD("ynu-mcl-act", user_id+"/send" , user_id + "/JSON/TEXT_LIST/" + now_kst1.strftime("%Y%m%d%H%M%S") + str(change[9]))

        return redirect('image.html')
    else:
        return redirect('image.html')


@csrf_exempt
def event_trans(request):    # 이벤트 전송 버튼 TEXT_LIST에서 선택된 TIMETABLE을 JSON/TIMETABLE로 전송
    print("----------------------------ss")
    check_list_text = value_of_request_body_list(request.body) # 선택된 파일 인덱스

    blobs = storage_client.list_blobs("ynu-mcl-act")
    ############ 이미지 정보 ############
    list_blob_img = []
    list_blob_text = []
    except_str = str(user_id + "/IMAGE/")  # 제외시킬 문자열
    except_str1 = str(user_id + "/JSON/TEXT_LIST/")  # 제외시킬 문자열
    for blob in blobs:
        if blob.name.startswith(except_str):
            blob.name = blob.name.replace(except_str, '')
            list_blob_img.append(blob.name)
        if blob.name.startswith(except_str1):
            blob.name = blob.name.replace(except_str1, '')
            list_blob_text.append(blob.name)

    call_text = []  # TEXT_LIST에서 선택된 문자를 담을 리스트
    call_img = []
    for index in range(40):
        if index < 20:  # 문자
            if check_list_text[index] != '':  # 체크된 인덱스
                if len(list_blob_text) > (index):  # 이미 업로드된 범위 내의 체크
                    call_text.append(list_blob_text[index])
                else:
                    pass
        else: # 이미지
            if check_list_text[index] != '':  # 체크된 인덱스
                if len(list_blob_img) > (index-20):  # 이미 업로드된 범위 내의 체크
                    call_img.append((list_blob_img[index-20]))
                else:
                    pass

    data = []
    now_kst = time_now_local()  # 현재시간 받아옴
    now_kst1 = time_now()
    now_kst += 15
    cum_time = 0


    for i in range(len(call_img)):  # 사진목록의 타임테이블 작성
        now_kst += cum_time
        # 시간 추출 부분
        len_t = int(call_img[i][14])  # (지속시간 길이)
        img_time = (str(call_img[i][15: 14 + len_t + 1]))  # 파일 이름 앞에 지속시간 분리 (첫자리 제외)
        img_name = (str(call_img[i][14 + len_t + 1:]))  # 나머지 파일이름 따로 저장

        # 파일이름만 추가
        info = {}
        info["time"] = {}
        info["time"]["year"] = str(time.localtime(now_kst).tm_year)
        info["time"]["month"] = str(time.localtime(now_kst).tm_mon)
        info["time"]["day"] = str(time.localtime(now_kst).tm_mday)
        info["time"]["hour"] = str(time.localtime(now_kst).tm_hour)
        info["time"]["minute"] = str(time.localtime(now_kst).tm_min)
        info["time"]["second"] = str(time.localtime(now_kst).tm_sec)
        info["type"] = "image"
        info["action"] = "play"
        info["title"] = str(img_name)
        data.append(info)

        now_kst += int(img_time)

        info = {}
        info["time"] = {}
        info["time"]["year"] = str(time.localtime(now_kst).tm_year)
        info["time"]["month"] = str(time.localtime(now_kst).tm_mon)
        info["time"]["day"] = str(time.localtime(now_kst).tm_mday)
        info["time"]["hour"] = str(time.localtime(now_kst).tm_hour)
        info["time"]["minute"] = str(time.localtime(now_kst).tm_min)
        info["time"]["second"] = str(time.localtime(now_kst).tm_sec)
        info["type"] = "image"
        info["action"] = "stop"
        data.append(info)

        cum_time += int(img_time) + 1
        # 해당 이미지 media/image/로 업로드
        copy_blob("ynu-mcl-act", user_id + "/IMAGE/" + str(call_img[i]), "ynu-mcl-act",
                  user_id + "/MEDIA/image/" + str(img_name))

        cum_time = 0
    for i in range(len(call_text)):
        DOWNLOAD("ynu-mcl-act", user_id + "/JSON/TEXT_LIST/" + call_text[i], user_id + "/temp")
        text_setting = read_json()
        cum_time += 1
        now_kst += cum_time

        info = {}
        info["time"] = {}
        info["detail_info"] = {}
        info["detail_info"]["x"] = text_setting[4]["detail_info"]["x"]
        info["detail_info"]["y"] = text_setting[4]["detail_info"]["y"]
        info["detail_info"]["width"] = text_setting[4]["detail_info"]["width"]
        info["detail_info"]["height"] = text_setting[4]["detail_info"]["height"]
        info["detail_info"]["scroll_fix"] = text_setting[4]["detail_info"]["scroll_fix"]
        info["detail_info"]["play_speed"] = text_setting[4]["detail_info"]["play_speed"]
        info["detail_info"]["play_count"] = text_setting[4]["detail_info"]["play_count"]
        info["detail_info"]["font_name"] = "NanumGothic"  # 추가필요
        info["detail_info"]["font_size"] = text_setting[4]["detail_info"]["font_size"]
        info["detail_info"]["play_second"] = text_setting[4]["detail_info"]["play_second"]
        info["detail_info"]["thickness_italics"] = "0"  # 추가필요
        info["detail_info"]["red_green_blue"] = text_setting[4]["detail_info"]["red_green_blue"]

        info["time"]["year"] = str(time.localtime(now_kst).tm_year)
        info["time"]["month"] = str(time.localtime(now_kst).tm_mon)
        info["time"]["day"] = str(time.localtime(now_kst).tm_mday)
        info["time"]["hour"] = str(time.localtime(now_kst).tm_hour)
        info["time"]["minute"] = str(time.localtime(now_kst).tm_min)
        info["time"]["second"] = str(time.localtime(now_kst).tm_sec)

        info["title"] = text_setting[4]["title"]
        info["type"] = "string"
        info["action"] = "play"
        data.append(info)

        if (str(text_setting[4]["detail_info"]["scroll_fix"]) == '0'):
            title = str(text_setting[4]["title"])
            len_text = len(title)
            all_text_pixel = int(0.9 * int(len_text) * int(text_setting[4]["detail_info"]["font_size"])) - int(
                text_setting[4]["detail_info"]["width"])
            micro_second = (all_text_pixel * 100) / int(text_setting[4]["detail_info"]["play_speed"])  # 100 is ms
            ans = np.rint((micro_second / 1000) * int(text_setting[4]["detail_info"]["play_count"]))
            now_kst = now_kst + ans + 1
            cum_time += (ans + 1)
        elif (str(text_setting[4]["detail_info"]["scroll_fix"]) == '1'):
            now_kst += (int(data[4]["detail_info"]["play_second"]) + 1)
            cum_time += (int(data[4]["detail_info"]["play_second"]) + 1)

        info = {}
        info["time"] = {}
        info["time"]["year"] = str(time.localtime(now_kst).tm_year)
        info["time"]["month"] = str(time.localtime(now_kst).tm_mon)
        info["time"]["day"] = str(time.localtime(now_kst).tm_mday)
        info["time"]["hour"] = str(time.localtime(now_kst).tm_hour)
        info["time"]["minute"] = str(time.localtime(now_kst).tm_min)
        info["time"]["second"] = str(time.localtime(now_kst).tm_sec)
        info["type"] = "string"
        info["action"] = "stop"
        data.append(info)


    save_file(data)
    UPLOAD("ynu-mcl-act", user_id + "/send",
           user_id + "/JSON/TIMETABLE/" + now_kst1.strftime("%Y%m%d%H%M%S"))

    return render(request, 'image.html')

